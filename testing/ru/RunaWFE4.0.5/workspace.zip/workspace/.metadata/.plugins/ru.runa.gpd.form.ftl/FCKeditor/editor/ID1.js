// jQuery version: 1.3.2

$(document).ready(function() {
	// called on document load
});