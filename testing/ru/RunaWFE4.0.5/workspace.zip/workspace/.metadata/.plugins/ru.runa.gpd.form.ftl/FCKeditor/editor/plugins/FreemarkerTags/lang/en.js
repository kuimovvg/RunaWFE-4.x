
FCKLang.OutputTitle	= 'Output variable' ;
FCKLang.MethodTitle	= 'Freemarker tag' ;
FCKLang.FtlVariable = 'Variable';
FCKLang.FtlMethodParameters = 'Parameters';
FCKLang.FtlFormat = 'Variable format';
FCKLang.FtlMethod = 'Tag';
