FCKLang.VarTagBtn		= 'Вставить/Редактировать элемент формы' ;
FCKLang.VarTagDlgTitle		= 'Свойства элемента формы' ;
FCKLang.VarTagDlgName		= 'Название элемента формы' ;
FCKLang.VarTagDlgType		= 'Тип элемента';
FCKLang.VarTagErrNoName		= 'Введите название элемента формы' ;

