﻿FCKLang.VarTagBtn		= 'Insert/Edit VarTag' ;
FCKLang.VarTagDlgTitle		= 'VarTag Properties' ;
FCKLang.VarTagDlgName		= 'Name' ;
FCKLang.VarTagDlgType		= 'Type';
FCKLang.VarTagErrNoName		= 'Please type the VarTag name' ;
