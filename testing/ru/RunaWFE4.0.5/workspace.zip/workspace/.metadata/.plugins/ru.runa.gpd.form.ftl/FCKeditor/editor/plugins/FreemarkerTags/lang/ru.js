
FCKLang.MethodTitle = 'Freemarker тег';
FCKLang.OutputTitle = 'Вывод переменной';
FCKLang.FtlVariable = 'Переменная';
FCKLang.FtlMethodParameters = 'Параметры';
FCKLang.FtlFormat = 'Формат переменной';
FCKLang.FtlMethod = 'Тег';
FCKLang.ErrNoVar = 'Выберите переменную';
FCKLang.ErrNoTagFormat = 'Выберите формат';
FCKLang.ErrNoTagType = 'Выберите тег';
FCKLang.ErrNotAllParamsSet = 'Заполните все параметры';

