
import ru.runa.wfe.webservice.*;

import java.util.*;

public class tst50 {

	public static void main(String[] args) {
		
		 try {
			 			    			    			    						 
	            AuthenticationAPI authenticationAPI = new AuthenticationWebService().getAuthenticationAPIPort();
	            User user = authenticationAPI.authenticateByLoginPassword("Administrator", "wf");
	            //DefinitionAPI definitionAPI = new DefinitionWebService().getDefinitionAPIPort();
	            ExecutionAPI executionAPI = new ExecutionWebService().getExecutionAPIPort();
	            
	           	            	            	                      	           	            	            
	            Boolean failure = false;	            	            

	     while(!failure)
	     {
	            List<Variable> variables = new ArrayList<Variable>();
	            List<WfProcess> sublist = new ArrayList<WfProcess>();
	            WfProcess owner_proc = new WfProcess();
	            Variable usersListVariable = new Variable();	            
	            List<String> listSubId = new ArrayList<String>();
	            
	            
	            System.out.println("--=Start test=--");
	            System.out.println(DateTimeNow());
	            //System.out.println("\r\n\r\n");
	           	            	            
	            usersListVariable.setName("������ �������������");
	            usersListVariable.setValue("[{\"name\": \"julius\"}, {\"name\": \"nero\"}, {\"name\": \"octavia\"}]");
	            variables.add(usersListVariable);

	            System.out.println("-=Start process=-");
	            System.out.println(DateTimeNow());
	            
	            Long processId = executionAPI.startProcessWS(user, "messagingFailureTest", variables);
	            System.out.println("Parent:" + processId);
	            	            	          
	            Thread.sleep(2000);
	            	           	            	            	            
	            while(sublist.isEmpty())
	            {
	            	Thread.sleep(1000);
	            	sublist = executionAPI.getSubprocesses(user, processId, true);	
	            }
	            	            	            	            
	            for(WfProcess pr:sublist)
	            {
	            	System.out.println("   Sub:" + pr.getId().toString());
	            	listSubId.add(pr.getId().toString());
	            }	            		              
	            
	            System.out.println(DateTimeNow());
	            System.out.println("Pause 8 minute...");
	            //Thread.sleep(600000);
	            Thread.sleep(480000);
	            
	            owner_proc = executionAPI.getProcess(user, processId);
	            sublist = executionAPI.getSubprocesses(user, processId, true);
	            
	            if(owner_proc.getEndDate()==null)	            
	            {
	            	failure = true;	       
	            	System.out.println(DateTimeNow());
	            	System.out.println("ERROR: ������� ������� �� ��������!!!");
	            }
	            else
	            {
	            	for(WfProcess pr:sublist)
	 	            {
	            		 if(pr.getEndDate()==null)
	            		 {
	            			 failure = true;
	            			 System.out.println(DateTimeNow());
	            			 System.out.println("ERROR: ���������� �� ��������!!!");
	            		 }	 	            		            			            
	 	            }		            	
	            }
	            
	            if(!failure)
	            {	            		            	
	            	List<Variable> own_variables = executionAPI.getVariablesWS(user, processId);
	            	
	            	for(Variable v1:own_variables)
	 	            {
	            		if(v1.getName().equals("���������� ������ ���������"))
	            		{
	            			String val = v1.getValue().toString();
	            			
	            			System.out.println("���������� ������ ���������: " + val);
	            				            				            		
	            			val = val.replace("[","").replace("]", "").replace("\"", "");	            				            				            				            			
	            			List<String> listNum = Arrays.asList(val.split("\\s*,\\s*"));
	            				            			
	            			if(listNum.size()!=listSubId.size())
	            			{
	            				failure = true;	     
	            				System.out.println(DateTimeNow());
	        	            	System.out.println("ERROR: �� ��� ������ ��������� ��������!!!");	            				
	            			}
	            			else
	            			{	    
	            					            				
	            				if(!listNum.containsAll(listSubId))
	            				{
	            					failure = true;	        
	            					System.out.println(DateTimeNow());
		        	            	System.out.println("ERROR: �������� �� ������ ������ ���������!!!");	            	
	            				}	            				
	            			}
	            			
	            			break;
	            		}
	 	            }
	            	
	            }
	            
	            if(failure)
	            {
	               System.out.println(DateTimeNow());
	               System.out.println("\r\n !!!!!  Test Failed !!!!!\r\n");
	            }
	            else
	            {
	            	System.out.println(DateTimeNow());
	            	System.out.println("\r\n !!!!!  Test SUCCESS !!!!!\r\n");
	            }
	          
	            
	     }
	     
	     
	     
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		

	}
	
	public static String DateTimeNow()
	{
		return new java.text.SimpleDateFormat("dd-MMM-yy hh:mm:ss aaa").format(java.util.Calendar.getInstance ().getTime());
	}
	

}
